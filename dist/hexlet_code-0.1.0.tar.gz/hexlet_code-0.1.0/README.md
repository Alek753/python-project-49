### Hexlet tests and linter status:
[![Actions Status](https://github.com/Alek753/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/Alek753/python-project-49/actions)

<a href="https://codeclimate.com/github/Alek753/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/01099b6f06eb56df74a9/maintainability" /></a>