### Hexlet tests and linter status:
[![Actions Status](https://github.com/Alek753/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/Alek753/python-project-49/actions)

<a href="https://codeclimate.com/github/Alek753/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/01099b6f06eb56df74a9/maintainability" /></a>

https://asciinema.org/a/I3CKKNMEk9pI7csOU5tF94C42

https://asciinema.org/a/CDOd4zcfytLroMr1HY4VinfnP

https://asciinema.org/a/qkhL2dt5dS3bpbZXVjGbg2xUC